D4-HOL-01 ARTIFACTS

01_Meridian_Customer_Feedback.csv
100 simulated feedback records. Use in Exercise 2 (Idea Coach) and Exercise 3 (Prompt Coach).

02_Meridian_Business_Context.docx
Business background, objectives, constraints, measures and recommendation expectations. Use in Exercises 2 and 3.

03_Management_Email_Draft.txt
Intentionally weak internal email draft. Use in Exercise 4 (Writing Coach).

All data and business details are fictional training material, not production data.
Do not add real personal, account, payment or confidential information.
Keep originals unchanged; copy relevant content into Copilot as instructed.
